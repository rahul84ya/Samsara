# dhara

dhara is a modern, accessible prop-tech mobile application for Andhra Pradesh land-record discovery. Inspired by the clarity of Landeed and the official record structure of Andhra Pradesh revenue services (Meebhoomi / Webland), this application provides guided location-based parcel lookup.

---

## 🏛️ Official API Configuration & Demo Mode

### Official Portal Mode (Default)
Out of the box, **dhara opens the official MeeBhoomi portal inside the app** for land-record and ownership requests.
- Users interact directly with `meebhoomi.ap.gov.in` and complete all login, CAPTCHA, and verification steps themselves.
- The app never scrapes the portal, calls undocumented portal endpoints, submits forms, or attempts CAPTCHA extraction or solving.
- District, mandal, and village selectors use a bundled LGD-derived snapshot (28 districts, 688 mandals, 17,954 villages) solely to help users identify their location before opening the portal. It is used under GODL-India with the required attribution in the source file.
- Parcel-boundary maps continue to use the separately identified APSAC cadastral GIS service and are labelled as visual reference only—not proof of title.

### Configuring Official Authorized APIs
The codebase features a strictly isolated `APLandRecordsService` layer (`com.example.data.service.APLandRecordsService`). When official government API agreements or state department endpoints are authorized:
1. Configure your endpoint URL and API credentials in `.env` (via the AI Studio Secrets panel):
   ```env
   AP_REVENUE_API_URL=https://api.ccla.ap.gov.in/v1/records
   AP_REVENUE_API_KEY=your_authorized_api_key_here
   ```
2. When valid credentials are present, `APLandRecordsService.isOfficialMode` activates automatically.
3. Official responses are clearly flagged with the **"Official AP Government API Data"** green verified badge in place of the demo banner.

---

## 🛡️ Compliance, Privacy & Anti-Scraping Policy

- **No Scraping:** This application strictly forbids web scraping, automated headless browser crawling, or bypassing CAPTCHA, firewalls, and rate limits of state government servers (such as Meebhoomi or Webland).
- **Privacy First:** Sensitive ownership searches require explicit user authorization consent.
- **No Data Retention:** In compliance with land data privacy guidelines, personal ownership and identity details are not permanently persisted to any local or external database by default.
- **Statutory Legal Notice:** This application is for informational discovery. Statutory transactions (mortgages, sales deeds, registered partitions) require certified extracts from the Sub-Registrar Office (Registration & Stamps Department) and the Mandal Revenue Officer (Tahsildar).

---

## 📱 Features Included in this Prototype

1. **Land Record Search:**
   - Guided, dependent selection hierarchy: District → Tahsil/Mandal → Village → Land Record Type → Survey Number.
   - Downstream dropdowns remain disabled until prior choices are made.
   - Record types supported: Adangal (Village Account No. 3), 1-B (Record of Rights), FMB Map, and E-Passbook.
   - Action buttons: View Record, Download PDF, Report Discrepancy (with user feedback).

2. **Ownership Check:**
   - Dedicated ownership tab using the same dependent revenue hierarchy.
   - Mandatory user authorization consent checkbox before verification.
   - Displays Pattadar name, relationship, ownership classification, registered extent, and undivided share percentage.

3. **Service Placeholders:**
   - Document Vault, Encumbrance Certificate (EC), Property Alerts, FMB Map Viewer, Saved Searches, Help, and Login/Profile.
