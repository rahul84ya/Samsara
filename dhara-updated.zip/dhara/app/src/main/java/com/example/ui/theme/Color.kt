package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Indian Tricolour inspired prop-tech palette
// Saffron / Warm Orange for primary active states, buttons & highlights
val SaffronPrimary = Color(0xFFD95300)
val SaffronDark = Color(0xFFB54100)
val SaffronLight = Color(0xFFFFECE0)
val SaffronContainer = Color(0xFFFFF3EB)
val OnSaffron = Color(0xFFFFFFFF)

// India Green for verified badges, secondary accents & success states
val IndiaGreen = Color(0xFF1B6B38)
val IndiaGreenLight = Color(0xFFE8F5E9)
val IndiaGreenDark = Color(0xFF135028)
val OnIndiaGreen = Color(0xFFFFFFFF)

// Clean white primary surfaces and subtle neutral borders
val SurfaceWhite = Color(0xFFFFFFFF)
val BackgroundNeutral = Color(0xFFF8FAFC)
val SurfaceVariant = Color(0xFFF1F5F9)
val BorderSubtle = Color(0xFFE2E8F0)
val BorderMedium = Color(0xFFCBD5E1)

// Navy / Slate Charcoal text for sharp, legible prop-tech contrast
val TextNavyDark = Color(0xFF0F172A)
val TextNavyMedium = Color(0xFF334155)
val TextMuted = Color(0xFF64748B)

// Status & Badge colors
val DemoBadgeBg = Color(0xFFFEF3C7)
val DemoBadgeText = Color(0xFF92400E)
val DemoBadgeBorder = Color(0xFFFDE68A)

val WarningRed = Color(0xFFDC2626)
